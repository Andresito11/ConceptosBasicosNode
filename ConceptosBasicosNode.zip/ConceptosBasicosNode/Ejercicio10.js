// Importar el módulo 'fs' para manejar archivos
const fs = require('fs');

// Función para leer el archivo en bloques
function leerArchivoEnBloques() {
    const archivo = 'largeData.txt';

    // Crear un flujo de lectura
    const stream = fs.createReadStream(archivo, { encoding: 'utf8', highWaterMark: 1024 }); // Leer en bloques de 1024 bytes

    // Manejar el evento 'data' para procesar cada bloque
    stream.on('data', (chunk) => {
        console.log('Nuevo bloque:');
        console.log(chunk);
    });

    // Manejar el evento 'error' en caso de que haya problemas al leer el archivo
    stream.on('error', (error) => {
        console.error(`Error al leer el archivo "${archivo}":`, error.message);
    });

    // Manejar el evento 'end' para saber que la lectura ha terminado
    stream.on('end', () => {
        console.log('Lectura completa del archivo.');
    });
}

// Llamar a la función
leerArchivoEnBloques();
