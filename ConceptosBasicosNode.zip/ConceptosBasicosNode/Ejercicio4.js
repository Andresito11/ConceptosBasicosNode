//Importar el módulo 'fs' para trabajar con archivos.
const fs = require('fs');

//Definir la función
function leerArchivo(){
    fs.readFile('data.txt', 'utf8', (error, data) => {
        if (error){
            console.error('Error al leer el archivo', error.message);
            
        }else{
            console.log('Contenido del archivo:');
            console.log(data);
        }
});
}

//Llamar a la función
leerArchivo();