//Función para escribir en un archivo
function escribirArchivo(){
    const texto = '¡Hola, mundo!';

    fs.writeFile('output.txt', texto, (error) => {
    if(error){
        console.error('Error al escribir el archivo', error.message);
    }else{
        console.log('Archivo escrito exitosamente');
    }
        
});
}

//Lamar a la función
escribirArchivo();