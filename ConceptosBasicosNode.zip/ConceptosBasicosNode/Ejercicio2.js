//Definimos la función.
function saludar(){
    console.log("¡Hola, Mundo!");
}

//Llamar a la función.
saludar();