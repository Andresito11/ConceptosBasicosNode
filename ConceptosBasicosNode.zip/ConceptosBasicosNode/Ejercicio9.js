// Importar el módulo 'fs' para trabajar con el sistema de archivos
const fs = require('fs');

// Función para verificar y eliminar el directorio
function eliminarDirectorioSiExiste() {
    const directorio = 'carpetaAntigua';

    // Verificar si el directorio existe
    fs.access(directorio, fs.constants.F_OK, (error) => {
        if (error) {
            console.log(`El directorio "${directorio}" no existe.`);
        } else {
            // Si el directorio existe, eliminarlo
            fs.rmdir(directorio, { recursive: true }, (err) => {
                if (err) {
                    console.error(`Error al eliminar el directorio "${directorio}":`, err.message);
                } else {
                    console.log(`El directorio "${directorio}" ha sido eliminado con éxito.`);
                }
            });
        }
    });
}

// Llamar a la función
eliminarDirectorioSiExiste();
