// Importar el módulo 'fs' para manejar archivos
const fs = require('fs');

// Función para copiar contenido de un archivo a otro
function copiarArchivo() {
    const archivoOrigen = 'source.txt';
    const archivoDestino = 'destination.txt';

    // Crear un flujo de lectura y un flujo de escritura
    const readStream = fs.createReadStream(archivoOrigen, { encoding: 'utf8' });
    const writeStream = fs.createWriteStream(archivoDestino);

    // Leer del archivo de origen y escribir en el archivo de destino
    readStream.pipe(writeStream);

    // Manejar eventos para detectar errores o confirmar el éxito
    readStream.on('error', (error) => {
        console.error(`Error al leer el archivo "${archivoOrigen}":`, error.message);
    });

    writeStream.on('error', (error) => {
        console.error(`Error al escribir en el archivo "${archivoDestino}":`, error.message);
    });

    writeStream.on('finish', () => {
        console.log(`El contenido de "${archivoOrigen}" se ha copiado a "${archivoDestino}" con éxito.`);
    });
}

// Llamar a la función
copiarArchivo();
