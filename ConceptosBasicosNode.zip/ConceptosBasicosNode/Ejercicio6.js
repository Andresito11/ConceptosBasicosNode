//Importar el módulo 'fs' para trabajar con archivos.
const fs = require('fs');

//Función para sobreescribir un archivo
function actualizarLog(){
    const texto = 'Actualización completada';

    //Usar fs.writeFile para sobreescribir el archivo
    fs.writeFile('log.txt', texto, (error) => {
        if(error){
            console.error('Error al escribir el archivo', error.message);
        }else{
            console.log('Archivo actualizado exitosamente');
        }
    });
}

//Llamar a la función
actualizarLog();