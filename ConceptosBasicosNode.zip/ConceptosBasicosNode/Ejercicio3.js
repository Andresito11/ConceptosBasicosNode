   // Definir la función
   function sumarNumeros(a, b) {
    const suma = a + b;
    console.log(`La suma de ${a} y ${b} es: ${suma}`);
}

// Llamar a la función
sumarNumeros(5, 3);