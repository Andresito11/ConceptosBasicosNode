//Importar el módulo 'fs' para trabajar con archivos.
const fs = require('fs');

//Función para verificar y eliminar el archivo
function verificarYEliminarArchivo(){
    const archivo = "temp.txt";

//Verificar si el arcchivo existe
fs.access(archivo, fs.constants.F_OK, (error) => {
    if(error){
        console.error('El archivo "${archivo}" no existe');
    }else{
        //Eliminar el archivo
        fs.unlink(archivo, (error) => {
            if(error){
                console.error('Error al eliminar el archivo', error.message);
            }else{
                console.log('Archivo eliminado exitosamente');
            }
        });
    }
});
}

//Llamar a la fucnión
verificarYEliminarArchivo();