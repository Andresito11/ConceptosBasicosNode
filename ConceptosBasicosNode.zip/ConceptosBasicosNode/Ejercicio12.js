// Importar el módulo 'fs' para manejar archivos
const fs = require('fs');

// Función para leer y escribir usando pipe
function usarPipeParaCopiar() {
    const archivoEntrada = 'entrada.txt';
    const archivoSalida = 'salida.txt';

    // Crear un flujo de lectura desde entrada.txt
    const readStream = fs.createReadStream(archivoEntrada, { encoding: 'utf8' });

    // Crear un flujo de escritura hacia salida.txt
    const writeStream = fs.createWriteStream(archivoSalida);

    // Usar pipe para conectar los flujos
    readStream.pipe(writeStream);

    // Manejar eventos
    readStream.on('error', (error) => {
        console.error(`Error al leer el archivo "${archivoEntrada}":`, error.message);
    });

    writeStream.on('error', (error) => {
        console.error(`Error al escribir en el archivo "${archivoSalida}":`, error.message);
    });

    writeStream.on('finish', () => {
        console.log(`El contenido de "${archivoEntrada}" se ha escrito en "${archivoSalida}" con éxito.`);
    });
}

// Llamar a la función
usarPipeParaCopiar();
