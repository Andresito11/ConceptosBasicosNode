//Importar el módulo 'fs' para trabajar con archivos.
const fs = require('fs');

//Función para verificar y crear el directorio
function crearDirectorioSiNoExiste(){
    const directorio = 'nuevaCarpeta';

    //Verificar si el directorio existe

    fs.access(directorio, fs.constants.F_OK, (error) => {
        if(error){
            console.error(`El directorio "${directorio}" no existe`);
            //Crear el directorio
            fs.mkdir(directorio, (error) => {
                if(error){
                    console.error('Error al crear el directorio', error.message);
                }else{
                    console.log('Directorio creado exitosamente');
                }
            });
        }else{
            console.log(`El directorio "${directorio}" ya existe`);
        }
    });
}

//Llamar a la función
crearDirectorioSiNoExiste();