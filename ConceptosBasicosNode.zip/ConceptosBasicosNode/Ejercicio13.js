// Importar el módulo 'fs' para trabajar con el sistema de archivos
const fs = require('fs');

// Función para verificar y crear el directorio
function verificarOCrearDirectorio() {
    const directorio = 'backup';

    // Verificar si el directorio existe
    fs.access(directorio, fs.constants.F_OK, (error) => {
        if (error) {
            // Si el directorio no existe, crearlo
            fs.mkdir(directorio, (err) => {
                if (err) {
                    console.error(`Error al crear el directorio "${directorio}":`, err.message);
                } else {
                    console.log(`El directorio "${directorio}" ha sido creado con éxito.`);
                }
            });
        } else {
            console.log(`El directorio "${directorio}" ya existe.`);
        }
    });
}

// Llamar a la función
verificarOCrearDirectorio();
